WF Instant Alert Bot — proyecto inicial

Este proyecto crea un bot de Telegram que responde /start, /status y /stop y
puede reenviar alertas que otra fuente autorizada le envíe por HTTP.

IMPORTANTE: NO obtiene ofertas directamente de Amazon Flex. Para recibir ofertas
reales hace falta una fuente de datos autorizada y compatible que envíe avisos
a la ruta /alert. No incluye scraping, acceso no autorizado ni aceptación automática.

CONFIGURACIÓN DE DESPLIEGUE:
1. Sube estos archivos a un repositorio privado de GitHub.
2. Crea un servicio Web en Render conectado a ese repositorio.
3. Configura estas variables de entorno en Render:
   BOT_TOKEN       = token de BotFather (mantener privado)
   ALERT_SECRET    = contraseña larga aleatoria
   WEBHOOK_SECRET  = otra contraseña larga aleatoria
   PUBLIC_URL      = URL HTTPS asignada por Render
4. Render instala requirements.txt y ejecuta:
   uvicorn app:app --host 0.0.0.0 --port $PORT
5. Abre el bot en Telegram y envía /start.

PRUEBA DE ALERTA (cuando esté desplegado):
POST https://TU-SERVICIO.onrender.com/alert
Header: X-Alert-Secret: TU_ALERT_SECRET
JSON: {"station":"Whole Foods White Plains","area":"White Plains, NY","details":"Prueba de alerta"}

LIMITACIONES:
- El plan gratuito puede entrar en reposo; no garantiza alertas instantáneas 24/7.
- Los suscriptores se guardan en memoria y se pierden si el servicio reinicia.
- /alert solo reenvía avisos que otra fuente le entregue.
- Nunca compartas el BOT_TOKEN. Si se expone, revócalo en BotFather y crea otro.
