import os
import logging
import requests
from fastapi import FastAPI, Request, Header, HTTPException

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("wf-bot")

BOT_TOKEN = os.environ["BOT_TOKEN"]
ALERT_SECRET = os.environ["ALERT_SECRET"]
WEBHOOK_SECRET = os.environ["WEBHOOK_SECRET"]
PUBLIC_URL = os.environ["PUBLIC_URL"].rstrip("/")
TELEGRAM_API = f"https://api.telegram.org/bot{BOT_TOKEN}"
app = FastAPI(title="WF Instant Alert Bot")
subscribers = set()


def telegram(method, payload):
    response = requests.post(f"{TELEGRAM_API}/{method}", json=payload, timeout=20)
    response.raise_for_status()
    data = response.json()
    if not data.get("ok"):
        raise RuntimeError(str(data))
    return data.get("result")


def send_message(chat_id, text):
    return telegram("sendMessage", {"chat_id": chat_id, "text": text, "disable_web_page_preview": True})


@app.on_event("startup")
def register_webhook():
    telegram("setWebhook", {"url": f"{PUBLIC_URL}/telegram", "secret_token": WEBHOOK_SECRET})
    log.info("Telegram webhook registered")


@app.get("/")
def home():
    return {"ok": True, "service": "WF Instant Alert Bot"}


@app.post("/telegram")
async def telegram_updates(request: Request, x_telegram_bot_api_secret_token: str = Header(default="")):
    if x_telegram_bot_api_secret_token != WEBHOOK_SECRET:
        raise HTTPException(status_code=401, detail="Invalid Telegram webhook secret")
    update = await request.json()
    message = update.get("message") or update.get("edited_message")
    if not message:
        return {"ok": True}
    chat_id = message["chat"]["id"]
    text = (message.get("text") or "").strip()
    if text.startswith("/start"):
        subscribers.add(chat_id)
        send_message(chat_id, "¡WF Instant Alert Bot está conectado!\n\nTe avisaré cuando una fuente autorizada envíe una alerta.\nComandos: /start, /status, /stop\n\nEste bot no obtiene ofertas directamente de Amazon Flex ni acepta ofertas.")
    elif text.startswith("/status"):
        send_message(chat_id, "Bot activo. Este chat está suscrito a las alertas enviadas a la conexión del bot. La fuente de ofertas todavía debe configurarse.")
    elif text.startswith("/stop"):
        subscribers.discard(chat_id)
        send_message(chat_id, "Avisos pausados. Escribe /start para volver a suscribirte.")
    else:
        send_message(chat_id, "Escribe /start para activar este chat o /status para revisar.")
    return {"ok": True}


@app.post("/alert")
async def receive_alert(request: Request, x_alert_secret: str = Header(default="")):
    if x_alert_secret != ALERT_SECRET:
        raise HTTPException(status_code=401, detail="Invalid alert secret")
    body = await request.json()
    station = str(body.get("station", "Whole Foods"))
    area = str(body.get("area", "White Plains, NY"))
    details = str(body.get("details", "Nueva alerta disponible"))
    message = ("🚨 ALERTA DE WHOLE FOODS\n" f"Zona: {area}\n" f"Estación: {station}\n" f"Detalle: {details}\n\n" "Revisa Amazon Flex y decide manualmente. Este bot no acepta ofertas.")
    sent = 0
    for chat_id in list(subscribers):
        try:
            send_message(chat_id, message)
            sent += 1
        except Exception:
            log.exception("Could not send alert to chat %s", chat_id)
    return {"ok": True, "sent": sent}


@app.get("/health")
def health():
    return {"ok": True}
